package com.example.commands;

import com.example.taxopark.Taxopark;

import java.util.Scanner;

public class ConsoleMenu {
    public static void mainMenu() {
        Taxopark tp = new Taxopark();

        Command create = new TaxoparkCreate(tp);
        Command addAuto = new TaxoparkAddAuto(tp);
        Command removeAuto = new TaxoparkRemoveAuto(tp);
        Command showList = new TaxoparkShowList(tp);
        Command sortList = new TaxoparkSortList(tp);
        Command searchAuto = new TaxoparkSearchAuto(tp);
        Command totalCost = new TaxoparkShowCost(tp);

        ConsoleMenuExecutor myConsoleMenuExecutor = new ConsoleMenuExecutor();
        myConsoleMenuExecutor.register("create", create);
        myConsoleMenuExecutor.register("addAuto", addAuto);
        myConsoleMenuExecutor.register("delAuto", removeAuto);
        myConsoleMenuExecutor.register("showList", showList);
        myConsoleMenuExecutor.register("sortList", sortList);
        myConsoleMenuExecutor.register("searchAuto", searchAuto);
        myConsoleMenuExecutor.register("totalCost", totalCost);

        while (true) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Виберіть дію:");
            System.out.println("\t1 - створити таксопарк.");
            System.out.println("\t2 - додати автомобіль.");
            System.out.println("\t3 - вилучити автомобіль.");
            System.out.println("\t4 - показати список автомобілів.");
            System.out.println("\t5 - показати вартість таксопарку.");
            System.out.println("\t6 - відсортувати автомобілі за зростанням витрати пального.");
            System.out.println("\t7 - знайти автомобіль.");
            System.out.println("\t8 - закінчити роботу.");
            int choice = sc.nextInt();

            switch (choice) {
                case 8:
                    return;
                case 1:
                    myConsoleMenuExecutor.execute("create");
                    break;
                case 2:
                    myConsoleMenuExecutor.execute("addAuto");
                    break;
                case 3:
                    myConsoleMenuExecutor.execute("delAuto");
                    break;
                case 4:
                    myConsoleMenuExecutor.execute("showList");
                    break;
                case 5:
                    myConsoleMenuExecutor.execute("totalCost");
                    break;
                case 6:
                    myConsoleMenuExecutor.execute("sortList");
                    break;
                case 7:
                    myConsoleMenuExecutor.execute("searchAuto");
                    break;
                default:
                    System.out.println("Необхідно ввести 1-8 варіанти\n");
            }
        }
    }
}