package com.example.auto;

import java.time.Year;

public class BaseAuto {
    private String brand;
    private String model;
    private int yearOfRelease;
    private String regNumber;
    private double initialPrice;
    private double uof;
    private int avgVelocity;

    private double amortCoef = 0.95;



    public BaseAuto(String brand, String model, int yearOfRelease, String regNumber, double initialPrice, double uof, int avgVelocity) {
        this.brand = brand;
        this.model = model;
        this.yearOfRelease = yearOfRelease;
        this.regNumber = regNumber;
        this.initialPrice = initialPrice;
        this.uof = uof;
        this.avgVelocity = avgVelocity;
    }

    public void setAmortCoef(double amortCoef) {
        this.amortCoef = amortCoef;
    }

    public String getRegNumber() {
        return regNumber;
    }

    public double getUoF() {
        return uof;
    }

    @Override
    public String toString() {
        return brand + " " + model + " (" + regNumber + ")";
    }

    public int getAge() {
        Year year = Year.now();
        return year.getValue() - this.yearOfRelease;
    }

    public double getPrice() {
        int age = this.getAge();
        double price = this.initialPrice * Math.pow(this.amortCoef, age);
        price = (double) Math.round(price * 10) / 10;
        return price;
    }

    public boolean velocityBetweenRange(double minVel, double maxVel) {
        return (minVel <= this.avgVelocity && this.avgVelocity <= maxVel);
    }

}
