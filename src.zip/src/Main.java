import com.example.auto.*;
import com.example.commands.ConsoleMenu;
import com.example.taxopark.Taxopark;

public class Main {
    public static void main(String[] args) {
        ConsoleMenu menu = new ConsoleMenu();
        menu.mainMenu();
    }
}